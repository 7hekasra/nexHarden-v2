"""Filesystem mount options and sensitive path audit."""

from __future__ import annotations

from pathlib import Path
from typing import List

from core.risk_engine import AuditState, Finding, Severity, make_finding
from core.system import SystemInfo


def audit(system: SystemInfo, full: bool = False) -> List[Finding]:
    findings: List[Finding] = []

    # Parse /proc/mounts for interesting options
    mounts = []
    try:
        with open("/proc/mounts", "r", encoding="utf-8") as fh:
            for line in fh:
                parts = line.split()
                if len(parts) >= 4:
                    mounts.append(
                        {
                            "device": parts[0],
                            "mountpoint": parts[1],
                            "fstype": parts[2],
                            "options": parts[3].split(","),
                        }
                    )
    except OSError:
        findings.append(
            make_finding(
                module="filesystem",
                check_id="fs.mounts",
                title="Mount table",
                description="Could not read /proc/mounts.",
                current="unavailable",
                expected="readable",
                severity=Severity.INFO,
                state=AuditState.UNKNOWN,
                risk="",
                recommendation="",
            )
        )
        return findings

    # Check /tmp for noexec/nosuid/nodev (recommended but not always present)
    tmp_mounts = [m for m in mounts if m["mountpoint"] == "/tmp"]
    if tmp_mounts:
        opts = set(tmp_mounts[0]["options"])
        missing = [o for o in ("noexec", "nosuid", "nodev") if o not in opts]
        if missing:
            findings.append(
                make_finding(
                    module="filesystem",
                    check_id="fs.tmp_options",
                    title="/tmp mount options",
                    description=f"Missing recommended options: {', '.join(missing)}",
                    current=",".join(sorted(opts)),
                    expected="noexec,nosuid,nodev where feasible",
                    severity=Severity.LOW,
                    state=AuditState.WARNING,
                    risk="Executable temporary directories aid certain attack techniques.",
                    recommendation="Consider mounting /tmp with noexec,nosuid,nodev (test applications first).",
                    evidence=str(tmp_mounts[0]),
                )
            )
        else:
            findings.append(
                make_finding(
                    module="filesystem",
                    check_id="fs.tmp_options",
                    title="/tmp mount options",
                    description="Recommended options present.",
                    current=",".join(sorted(opts)),
                    expected="noexec,nosuid,nodev",
                    severity=Severity.INFO,
                    state=AuditState.PASS,
                    risk="",
                    recommendation="",
                    evidence=str(opts),
                )
            )
    else:
        findings.append(
            make_finding(
                module="filesystem",
                check_id="fs.tmp_options",
                title="/tmp mount options",
                description="/tmp is not a separate mount.",
                current="not separate",
                expected="separate mount with restrictive options (optional)",
                severity=Severity.INFO,
                state=AuditState.NA,
                risk="",
                recommendation="Optional hardening: dedicated /tmp partition.",
            )
        )

    # World-writable directories outside expected locations (sample)
    # Only a lightweight check to avoid expensive walks
    findings.append(
        make_finding(
            module="filesystem",
            check_id="fs.mount_count",
            title="Mounted filesystems",
            description=f"{len(mounts)} entries in mount table.",
            current=str(len(mounts)),
            expected="expected for system role",
            severity=Severity.INFO,
            state=AuditState.PASS,
            risk="",
            recommendation="Review mount options for sensitive paths.",
            evidence=f"{len(mounts)} mounts",
        )
    )

    return findings
