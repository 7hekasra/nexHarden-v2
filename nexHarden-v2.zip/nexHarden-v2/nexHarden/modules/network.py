"""Network security parameters audit."""

from __future__ import annotations

from typing import List

from core.risk_engine import AuditState, Finding, Severity, make_finding
from core.system import SystemInfo
from core.validators import parse_sysctl


NET_CHECKS = [
    (
        "net.ipv4.ip_forward",
        "0",
        Severity.MEDIUM,
        "IPv4 forwarding",
        "Forwarding turns the host into a router; disable if not required.",
        "Set net.ipv4.ip_forward=0 unless the host is a router.",
    ),
    (
        "net.ipv4.conf.all.accept_redirects",
        "0",
        Severity.MEDIUM,
        "Accept ICMP redirects (all)",
        "ICMP redirects can be used for traffic redirection attacks.",
        "Set net.ipv4.conf.all.accept_redirects=0",
    ),
    (
        "net.ipv4.conf.default.accept_redirects",
        "0",
        Severity.MEDIUM,
        "Accept ICMP redirects (default)",
        "ICMP redirects can be used for traffic redirection attacks.",
        "Set net.ipv4.conf.default.accept_redirects=0",
    ),
    (
        "net.ipv4.conf.all.send_redirects",
        "0",
        Severity.LOW,
        "Send ICMP redirects",
        "Sending redirects is unnecessary on non-routers.",
        "Set net.ipv4.conf.all.send_redirects=0",
    ),
    (
        "net.ipv4.conf.all.accept_source_route",
        "0",
        Severity.MEDIUM,
        "Source routing",
        "Source routing can bypass network controls.",
        "Set net.ipv4.conf.all.accept_source_route=0",
    ),
    (
        "net.ipv4.conf.all.rp_filter",
        "1",
        Severity.MEDIUM,
        "Reverse path filtering",
        "Weak RP filter allows spoofed packets.",
        "Set net.ipv4.conf.all.rp_filter=1 (or 2)",
    ),
]


def audit(system: SystemInfo, full: bool = False) -> List[Finding]:
    findings: List[Finding] = []

    for key, expected, severity, title, risk, recommendation in NET_CHECKS:
        val = parse_sysctl(key)
        if val is None:
            findings.append(
                make_finding(
                    module="network",
                    check_id=f"net.{key}",
                    title=title,
                    description=f"{key} unavailable.",
                    current="unavailable",
                    expected=expected,
                    severity=Severity.INFO,
                    state=AuditState.NA,
                    risk="",
                    recommendation="",
                )
            )
            continue

        try:
            ok = int(val) >= int(expected) if key.endswith("rp_filter") else val == expected
        except ValueError:
            ok = val == expected

        # Special case: forwarding may be intentional
        state = AuditState.PASS if ok else (
            AuditState.WARNING if key.endswith("ip_forward") else AuditState.FAIL
        )

        findings.append(
            make_finding(
                module="network",
                check_id=f"net.{key}",
                title=title,
                description=f"{key} = {val}",
                current=val,
                expected=expected,
                severity=severity if not ok else Severity.INFO,
                state=state,
                risk=risk if not ok else "",
                recommendation=recommendation if not ok else "",
                evidence=f"sysctl {key}={val}",
                auto_fixable=not ok,
            )
        )

    # Interfaces
    findings.append(
        make_finding(
            module="network",
            check_id="net.interfaces",
            title="Active network interfaces",
            description=f"Up interfaces: {', '.join(system.active_interfaces) or 'none'}",
            current=", ".join(system.active_interfaces) or "none",
            expected="expected interfaces for role",
            severity=Severity.INFO,
            state=AuditState.PASS,
            risk="",
            recommendation="Review for unexpected interfaces.",
            evidence=str(system.active_interfaces),
        )
    )

    return findings
