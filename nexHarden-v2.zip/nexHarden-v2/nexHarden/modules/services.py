"""System services audit."""

from __future__ import annotations

from typing import List

from core.risk_engine import AuditState, Finding, Severity, make_finding
from core.system import SystemInfo
from core.validators import run_cmd


# Services that are often unnecessary on minimal servers
POTENTIALLY_UNNEEDED = [
    "avahi-daemon",
    "cups",
    "cups-browsed",
    "bluetooth",
    "ModemManager",
]


def audit(system: SystemInfo, full: bool = False) -> List[Finding]:
    findings: List[Finding] = []

    if system.init_system != "systemd":
        findings.append(
            make_finding(
                module="services",
                check_id="svc.init",
                title="Init system",
                description=f"Init system is {system.init_system}.",
                current=system.init_system,
                expected="systemd for full service checks",
                severity=Severity.INFO,
                state=AuditState.NA,
                risk="",
                recommendation="",
            )
        )
        return findings

    # Failed units
    code, out, _ = run_cmd(["systemctl", "--failed", "--no-legend", "--no-pager"])
    failed = [line.strip() for line in out.splitlines() if line.strip()] if code == 0 else []
    if failed:
        findings.append(
            make_finding(
                module="services",
                check_id="svc.failed",
                title="Failed systemd units",
                description=f"{len(failed)} failed unit(s).",
                current=str(len(failed)),
                expected="0",
                severity=Severity.MEDIUM,
                state=AuditState.WARNING,
                risk="Failed services may indicate misconfiguration or attack aftermath.",
                recommendation="Investigate: systemctl --failed",
                evidence="\n".join(failed[:10]),
            )
        )
    else:
        findings.append(
            make_finding(
                module="services",
                check_id="svc.failed",
                title="Failed systemd units",
                description="No failed units reported.",
                current="0",
                expected="0",
                severity=Severity.INFO,
                state=AuditState.PASS,
                risk="",
                recommendation="",
                evidence="systemctl --failed",
            )
        )

    # Potentially unnecessary services
    running_unneeded = []
    for svc in POTENTIALLY_UNNEEDED:
        code, out, _ = run_cmd(["systemctl", "is-active", svc])
        if code == 0 and out.strip() == "active":
            running_unneeded.append(svc)

    if running_unneeded and system.is_server:
        findings.append(
            make_finding(
                module="services",
                check_id="svc.unneeded",
                title="Potentially unnecessary services",
                description=f"Active: {', '.join(running_unneeded)}",
                current=", ".join(running_unneeded),
                expected="disabled if not required",
                severity=Severity.LOW,
                state=AuditState.WARNING,
                risk="Unused network-facing services expand attack surface.",
                recommendation="Disable services not required for the system role.",
                evidence=str(running_unneeded),
            )
        )
    else:
        findings.append(
            make_finding(
                module="services",
                check_id="svc.unneeded",
                title="Potentially unnecessary services",
                description="No commonly unnecessary services detected as active.",
                current="none",
                expected="none (role-dependent)",
                severity=Severity.INFO,
                state=AuditState.PASS,
                risk="",
                recommendation="",
                evidence="checked common desktop services",
            )
        )

    return findings
