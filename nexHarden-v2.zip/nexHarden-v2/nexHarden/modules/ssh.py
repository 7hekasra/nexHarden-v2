"""SSH security audit module."""

from __future__ import annotations

from typing import List

from core.risk_engine import (
    AuditState,
    Finding,
    Severity,
    make_finding,
)
from core.system import SystemInfo
from core.validators import get_effective_sshd_config, run_cmd


def audit(system: SystemInfo, full: bool = False) -> List[Finding]:
    findings: List[Finding] = []

    ok, cfg = get_effective_sshd_config()
    if not ok:
        findings.append(
            make_finding(
                module="ssh",
                check_id="ssh.effective_config",
                title="Unable to read effective SSH configuration",
                description="sshd -T failed or sshd is not installed.",
                current="unavailable",
                expected="readable effective config",
                severity=Severity.MEDIUM,
                state=AuditState.UNKNOWN,
                risk="Cannot verify SSH hardening state.",
                recommendation="Install openssh-server and ensure sshd is available.",
                evidence="sshd -T returned non-zero or binary missing",
            )
        )
        return findings

    # Helper
    def check(
        key: str,
        check_id: str,
        title: str,
        bad_values: set,
        expected: str,
        severity: Severity,
        risk: str,
        recommendation: str,
        state_on_bad: AuditState = AuditState.FAIL,
    ) -> None:
        val = cfg.get(key.lower(), cfg.get(key, "unset"))
        current = str(val)
        if current.lower() in {v.lower() for v in bad_values} or (
            "unset" in bad_values and current == "unset"
        ):
            findings.append(
                make_finding(
                    module="ssh",
                    check_id=check_id,
                    title=title,
                    description=f"Effective value of {key} is '{current}'.",
                    current=current,
                    expected=expected,
                    severity=severity,
                    state=state_on_bad,
                    risk=risk,
                    recommendation=recommendation,
                    auto_fixable=False,
                    evidence=f"sshd -T: {key} {current}",
                    references=["https://man.openbsd.org/sshd_config"],
                )
            )
        else:
            findings.append(
                make_finding(
                    module="ssh",
                    check_id=check_id,
                    title=title,
                    description=f"Effective value of {key} is '{current}'.",
                    current=current,
                    expected=expected,
                    severity=Severity.INFO,
                    state=AuditState.PASS,
                    risk="",
                    recommendation="",
                    evidence=f"sshd -T: {key} {current}",
                )
            )

    check(
        "permitrootlogin",
        "ssh.permit_root_login",
        "Root login via SSH",
        {"yes", "without-password", "prohibit-password"},
        "no",
        Severity.HIGH,
        "Allowing root login increases the impact of credential compromise.",
        "Set PermitRootLogin no and use sudo with individual accounts.",
    )

    check(
        "passwordauthentication",
        "ssh.password_auth",
        "Password authentication",
        {"yes"},
        "no (prefer public key)",
        Severity.MEDIUM,
        "Password authentication is susceptible to brute-force and credential stuffing.",
        "Disable PasswordAuthentication and use public-key authentication.",
        state_on_bad=AuditState.WARNING,
    )

    check(
        "permitemptypasswords",
        "ssh.empty_passwords",
        "Empty passwords",
        {"yes"},
        "no",
        Severity.CRITICAL,
        "Empty passwords allow unauthenticated access.",
        "Set PermitEmptyPasswords no.",
    )

    check(
        "x11forwarding",
        "ssh.x11_forwarding",
        "X11 forwarding",
        {"yes"},
        "no",
        Severity.LOW,
        "X11 forwarding can expose graphical session risks.",
        "Set X11Forwarding no unless required.",
        state_on_bad=AuditState.WARNING,
    )

    check(
        "maxauthtries",
        "ssh.max_auth_tries",
        "Maximum authentication attempts",
        set(),  # custom logic
        "<= 4",
        Severity.MEDIUM,
        "High MaxAuthTries increases brute-force window.",
        "Set MaxAuthTries 3 or 4.",
    )
    # Manual MaxAuthTries evaluation
    try:
        mat = int(cfg.get("maxauthtries", "6"))
        if mat > 4:
            findings[-1] = make_finding(
                module="ssh",
                check_id="ssh.max_auth_tries",
                title="Maximum authentication attempts",
                description=f"MaxAuthTries is {mat}.",
                current=str(mat),
                expected="<= 4",
                severity=Severity.MEDIUM,
                state=AuditState.WARNING,
                risk="Higher values give attackers more guesses per connection.",
                recommendation="Set MaxAuthTries 3 or 4.",
                evidence=f"sshd -T: maxauthtries {mat}",
            )
        else:
            findings[-1] = make_finding(
                module="ssh",
                check_id="ssh.max_auth_tries",
                title="Maximum authentication attempts",
                description=f"MaxAuthTries is {mat}.",
                current=str(mat),
                expected="<= 4",
                severity=Severity.INFO,
                state=AuditState.PASS,
                risk="",
                recommendation="",
                evidence=f"sshd -T: maxauthtries {mat}",
            )
    except ValueError:
        pass

    # PubkeyAuthentication
    pka = cfg.get("pubkeyauthentication", "yes").lower()
    if pka != "yes":
        findings.append(
            make_finding(
                module="ssh",
                check_id="ssh.pubkey_auth",
                title="Public key authentication",
                description=f"PubkeyAuthentication is '{pka}'.",
                current=pka,
                expected="yes",
                severity=Severity.MEDIUM,
                state=AuditState.WARNING,
                risk="Without public-key auth, only weaker methods may remain.",
                recommendation="Enable PubkeyAuthentication yes.",
                evidence=f"sshd -T: pubkeyauthentication {pka}",
            )
        )
    else:
        findings.append(
            make_finding(
                module="ssh",
                check_id="ssh.pubkey_auth",
                title="Public key authentication",
                description="PubkeyAuthentication is enabled.",
                current=pka,
                expected="yes",
                severity=Severity.INFO,
                state=AuditState.PASS,
                risk="",
                recommendation="",
                evidence=f"sshd -T: pubkeyauthentication {pka}",
            )
        )

    # Service status
    if system.ssh_service != "unknown":
        code, out, _ = run_cmd(["systemctl", "is-active", system.ssh_service])
        active = out.strip() == "active" if code == 0 else False
        findings.append(
            make_finding(
                module="ssh",
                check_id="ssh.service_status",
                title="SSH service status",
                description=f"Service '{system.ssh_service}' is {'active' if active else 'inactive'}.",
                current="active" if active else "inactive",
                expected="active (if remote admin needed)",
                severity=Severity.INFO,
                state=AuditState.PASS if active else AuditState.WARNING,
                risk="Inactive SSH may be intentional on local-only systems.",
                recommendation="Ensure SSH is running only if remote administration is required.",
                evidence=f"systemctl is-active {system.ssh_service}",
            )
        )

    # Listening port info
    findings.append(
        make_finding(
            module="ssh",
            check_id="ssh.listening_port",
            title="SSH listening port",
            description=f"Detected SSH port: {system.ssh_port}",
            current=str(system.ssh_port),
            expected="non-default optional; 22 common",
            severity=Severity.INFO,
            state=AuditState.PASS,
            risk="Default port is frequently scanned; changing is security-through-obscurity only.",
            recommendation="Consider a non-standard port only as a minor additional control.",
            evidence=f"Detected port {system.ssh_port}",
        )
    )

    return findings
