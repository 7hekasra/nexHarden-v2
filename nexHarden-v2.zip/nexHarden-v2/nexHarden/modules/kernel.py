"""Kernel parameter security audit."""

from __future__ import annotations

from typing import List, Optional, Tuple

from core.risk_engine import AuditState, Finding, Severity, make_finding
from core.system import SystemInfo
from core.validators import parse_sysctl


CHECKS = [
    # key, expected, severity, title, risk, recommendation
    (
        "kernel.randomize_va_space",
        "2",
        Severity.HIGH,
        "ASLR (randomize_va_space)",
        "Disabled or partial ASLR makes memory-corruption exploits easier.",
        "Set kernel.randomize_va_space=2",
    ),
    (
        "kernel.kptr_restrict",
        "1",
        Severity.MEDIUM,
        "Kernel pointer restriction",
        "Exposed kernel pointers aid local exploitation.",
        "Set kernel.kptr_restrict=1 (or 2)",
    ),
    (
        "kernel.dmesg_restrict",
        "1",
        Severity.MEDIUM,
        "dmesg restriction",
        "Unrestricted dmesg can leak kernel addresses and sensitive info.",
        "Set kernel.dmesg_restrict=1",
    ),
    (
        "fs.suid_dumpable",
        "0",
        Severity.MEDIUM,
        "SUID dumpable",
        "SUID processes producing core dumps can leak sensitive data.",
        "Set fs.suid_dumpable=0",
    ),
    (
        "kernel.yama.ptrace_scope",
        "1",
        Severity.MEDIUM,
        "Yama ptrace scope",
        "Unrestricted ptrace allows process injection and credential theft.",
        "Set kernel.yama.ptrace_scope=1",
    ),
]


def audit(system: SystemInfo, full: bool = False) -> List[Finding]:
    findings: List[Finding] = []

    for key, expected, severity, title, risk, recommendation in CHECKS:
        val = parse_sysctl(key)
        if val is None:
            findings.append(
                make_finding(
                    module="kernel",
                    check_id=f"kernel.{key}",
                    title=title,
                    description=f"Sysctl {key} is not available on this kernel.",
                    current="unavailable",
                    expected=expected,
                    severity=Severity.INFO,
                    state=AuditState.NA,
                    risk="",
                    recommendation="",
                    evidence=f"/proc/sys/{key.replace('.', '/')} missing",
                )
            )
            continue

        # Accept higher-or-equal restriction where numeric
        try:
            current_i = int(val)
            expected_i = int(expected)
            # For these keys higher is generally stricter (except suid_dumpable)
            if key == "fs.suid_dumpable":
                ok = current_i == 0
            else:
                ok = current_i >= expected_i
        except ValueError:
            ok = val == expected

        if ok:
            findings.append(
                make_finding(
                    module="kernel",
                    check_id=f"kernel.{key}",
                    title=title,
                    description=f"{key} = {val}",
                    current=val,
                    expected=expected,
                    severity=Severity.INFO,
                    state=AuditState.PASS,
                    risk="",
                    recommendation="",
                    evidence=f"sysctl {key}={val}",
                )
            )
        else:
            findings.append(
                make_finding(
                    module="kernel",
                    check_id=f"kernel.{key}",
                    title=title,
                    description=f"{key} = {val} (expected {expected})",
                    current=val,
                    expected=expected,
                    severity=severity,
                    state=AuditState.FAIL,
                    risk=risk,
                    recommendation=recommendation,
                    evidence=f"sysctl {key}={val}",
                    auto_fixable=True,
                )
            )

    # Optional unprivileged BPF
    bpf = parse_sysctl("kernel.unprivileged_bpf_disabled")
    if bpf is not None:
        ok = bpf in ("1", "2")
        findings.append(
            make_finding(
                module="kernel",
                check_id="kernel.unprivileged_bpf",
                title="Unprivileged BPF",
                description=f"kernel.unprivileged_bpf_disabled = {bpf}",
                current=bpf,
                expected="1 or 2",
                severity=Severity.MEDIUM if not ok else Severity.INFO,
                state=AuditState.PASS if ok else AuditState.WARNING,
                risk="Unprivileged BPF can be abused for local attacks.",
                recommendation="Set kernel.unprivileged_bpf_disabled=1",
                evidence=f"sysctl value {bpf}",
            )
        )

    return findings
