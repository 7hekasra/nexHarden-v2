"""nexHarden audit modules."""
