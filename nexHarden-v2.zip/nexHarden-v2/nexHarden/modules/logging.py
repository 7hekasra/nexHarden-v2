"""Logging and journal configuration audit."""

from __future__ import annotations

from pathlib import Path
from typing import List

from core.risk_engine import AuditState, Finding, Severity, make_finding
from core.system import SystemInfo
from core.validators import run_cmd


def audit(system: SystemInfo, full: bool = False) -> List[Finding]:
    findings: List[Finding] = []

    # journald persistent storage
    journal_dir = Path("/var/log/journal")
    persistent = journal_dir.exists() and any(journal_dir.iterdir()) if journal_dir.exists() else False

    # Also check Storage= in journald.conf
    conf = Path("/etc/systemd/journald.conf")
    storage_setting = "auto"
    if conf.exists():
        try:
            for line in conf.read_text(encoding="utf-8").splitlines():
                if line.strip().startswith("Storage="):
                    storage_setting = line.split("=", 1)[1].strip()
        except OSError:
            pass

    is_persistent = persistent or storage_setting.lower() == "persistent"
    findings.append(
        make_finding(
            module="logging",
            check_id="log.journal_persistent",
            title="Persistent journal storage",
            description=f"Storage setting: {storage_setting}; /var/log/journal present: {persistent}",
            current="persistent" if is_persistent else "volatile/auto",
            expected="persistent on servers",
            severity=Severity.LOW,
            state=AuditState.PASS if is_persistent else AuditState.WARNING,
            risk="Volatile journal loses logs on reboot, harming incident response.",
            recommendation="Set Storage=persistent in journald.conf and create /var/log/journal.",
            evidence=f"Storage={storage_setting}",
        )
    )

    # rsyslog presence
    rsyslog = Path("/etc/rsyslog.conf").exists() or Path("/etc/rsyslog.d").exists()
    findings.append(
        make_finding(
            module="logging",
            check_id="log.rsyslog",
            title="rsyslog configuration",
            description="rsyslog config presence.",
            current="present" if rsyslog else "not found",
            expected="present or journald-only acceptable",
            severity=Severity.INFO,
            state=AuditState.PASS if rsyslog else (AuditState.PASS if system.init_system == "systemd" else AuditState.WARNING),
            risk="",
            recommendation="Ensure a reliable logging pipeline exists.",
            evidence="checked /etc/rsyslog*",
        )
    )

    # Time sync (systemd-timesyncd or chrony/ntp)
    time_sync = False
    if system.init_system == "systemd":
        code, out, _ = run_cmd(["systemctl", "is-active", "systemd-timesyncd"])
        if code == 0 and out.strip() == "active":
            time_sync = True
        code, out, _ = run_cmd(["systemctl", "is-active", "chrony"])
        if code == 0 and out.strip() == "active":
            time_sync = True
        code, out, _ = run_cmd(["systemctl", "is-active", "ntp"])
        if code == 0 and out.strip() == "active":
            time_sync = True

    findings.append(
        make_finding(
            module="logging",
            check_id="log.time_sync",
            title="Time synchronization",
            description="Checked for active time sync service.",
            current="active" if time_sync else "not detected",
            expected="active",
            severity=Severity.MEDIUM if not time_sync else Severity.INFO,
            state=AuditState.PASS if time_sync else AuditState.WARNING,
            risk="Incorrect time breaks log correlation and certificate validity.",
            recommendation="Enable systemd-timesyncd, chrony, or ntp.",
            evidence="systemctl is-active checks",
        )
    )

    return findings
