"""Firewall security audit module."""

from __future__ import annotations

from typing import List

from core.risk_engine import AuditState, Finding, Severity, make_finding
from core.system import SystemInfo
from core.validators import run_cmd


def audit(system: SystemInfo, full: bool = False) -> List[Finding]:
    findings: List[Finding] = []
    backend = system.firewall_backend

    findings.append(
        make_finding(
            module="firewall",
            check_id="firewall.backend",
            title="Firewall backend detected",
            description=f"Active/detected firewall backend: {backend}",
            current=backend,
            expected="ufw, nftables, iptables, or firewalld",
            severity=Severity.INFO,
            state=AuditState.PASS if backend != "none" else AuditState.WARNING,
            risk="No firewall increases exposure of listening services.",
            recommendation="Enable and configure a host firewall appropriate for the system role.",
            evidence=f"Detected: {backend}",
        )
    )

    if backend == "none":
        findings.append(
            make_finding(
                module="firewall",
                check_id="firewall.active",
                title="Host firewall active",
                description="No supported firewall backend appears to be active.",
                current="inactive",
                expected="active with restrictive default policy",
                severity=Severity.HIGH,
                state=AuditState.FAIL,
                risk="Without a host firewall, all listening services are reachable according to network path.",
                recommendation="Install and enable UFW (or nftables/firewalld) and set a default deny inbound policy.",
                evidence="No ufw/nft/iptables/firewalld active ruleset detected",
            )
        )
        return findings

    # UFW specific
    if "ufw" in backend:
        code, out, _ = run_cmd(["ufw", "status", "verbose"])
        if code == 0:
            active = "Status: active" in out
            findings.append(
                make_finding(
                    module="firewall",
                    check_id="firewall.ufw_status",
                    title="UFW status",
                    description="UFW reported status.",
                    current="active" if active else "inactive",
                    expected="active",
                    severity=Severity.HIGH if not active else Severity.INFO,
                    state=AuditState.PASS if active else AuditState.FAIL,
                    risk="Inactive UFW leaves the system without its configured rules.",
                    recommendation="Run: sudo ufw enable (after reviewing rules).",
                    evidence=out[:500],
                )
            )
            # Default policy
            if "Default: deny (incoming)" in out or "Default: reject (incoming)" in out:
                findings.append(
                    make_finding(
                        module="firewall",
                        check_id="firewall.default_inbound",
                        title="Default inbound policy",
                        description="UFW default incoming policy is restrictive.",
                        current="deny/reject",
                        expected="deny or reject",
                        severity=Severity.INFO,
                        state=AuditState.PASS,
                        risk="",
                        recommendation="",
                        evidence="UFW status verbose",
                    )
                )
            elif active:
                findings.append(
                    make_finding(
                        module="firewall",
                        check_id="firewall.default_inbound",
                        title="Default inbound policy",
                        description="UFW default incoming policy may not be deny.",
                        current="see evidence",
                        expected="deny (incoming)",
                        severity=Severity.MEDIUM,
                        state=AuditState.WARNING,
                        risk="Permissive default inbound policy reduces effectiveness.",
                        recommendation="Set: sudo ufw default deny incoming",
                        evidence=out[:300],
                    )
                )

    # Generic listening services note
    code, out, _ = run_cmd(["ss", "-tuln"])
    if code == 0:
        listening = [
            line for line in out.splitlines()
            if "LISTEN" in line or "UNCONN" in line
        ]
        findings.append(
            make_finding(
                module="firewall",
                check_id="firewall.listening_sockets",
                title="Listening network sockets",
                description=f"Found {len(listening)} listening/UDP sockets.",
                current=str(len(listening)),
                expected="minimal set required for role",
                severity=Severity.INFO,
                state=AuditState.PASS,
                risk="Each listening service expands the attack surface.",
                recommendation="Review listening services and restrict via firewall rules.",
                evidence="\n".join(listening[:15]),
            )
        )

    return findings
