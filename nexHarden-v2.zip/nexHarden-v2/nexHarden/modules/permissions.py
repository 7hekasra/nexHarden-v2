"""Critical file permissions audit."""

from __future__ import annotations

import os
import stat
from pathlib import Path
from typing import List, Tuple

from core.risk_engine import AuditState, Finding, Severity, make_finding
from core.system import SystemInfo


CRITICAL_FILES = [
    ("/etc/passwd", 0o644, 0, 0),
    ("/etc/shadow", 0o640, 0, 0),  # or 600
    ("/etc/group", 0o644, 0, 0),
    ("/etc/gshadow", 0o640, 0, 0),
    ("/etc/ssh/sshd_config", 0o600, 0, 0),
]


def _check_mode(path: Path, expected_max: int) -> Tuple[bool, str, str]:
    try:
        st = path.stat()
        mode = stat.S_IMODE(st.st_mode)
        current = oct(mode)
        # Accept if mode is equal or more restrictive
        ok = (mode & ~expected_max) == 0
        return ok, current, oct(expected_max)
    except OSError as exc:
        return False, str(exc), oct(expected_max)


def audit(system: SystemInfo, full: bool = False) -> List[Finding]:
    findings: List[Finding] = []

    for path_str, max_mode, exp_uid, exp_gid in CRITICAL_FILES:
        path = Path(path_str)
        if not path.exists():
            findings.append(
                make_finding(
                    module="permissions",
                    check_id=f"perm.{path.name}",
                    title=f"Permissions of {path_str}",
                    description="File does not exist.",
                    current="missing",
                    expected=f"mode <= {oct(max_mode)}",
                    severity=Severity.LOW,
                    state=AuditState.NA,
                    risk="",
                    recommendation="",
                )
            )
            continue

        ok, current, expected = _check_mode(path, max_mode)
        try:
            st = path.stat()
            owner_ok = st.st_uid == exp_uid
        except OSError:
            owner_ok = True

        if ok and owner_ok:
            findings.append(
                make_finding(
                    module="permissions",
                    check_id=f"perm.{path.name}",
                    title=f"Permissions of {path_str}",
                    description="Ownership and mode are within expected bounds.",
                    current=current,
                    expected=expected,
                    severity=Severity.INFO,
                    state=AuditState.PASS,
                    risk="",
                    recommendation="",
                    evidence=f"mode={current}",
                )
            )
        else:
            sev = Severity.HIGH if "shadow" in path_str else Severity.MEDIUM
            findings.append(
                make_finding(
                    module="permissions",
                    check_id=f"perm.{path.name}",
                    title=f"Permissions of {path_str}",
                    description="Mode or ownership is less restrictive than recommended.",
                    current=current,
                    expected=expected,
                    severity=sev,
                    state=AuditState.FAIL,
                    risk="Overly permissive sensitive files can leak credentials or allow tampering.",
                    recommendation=f"chmod {expected} {path_str} and ensure root ownership.",
                    evidence=f"mode={current}",
                    auto_fixable=False,
                )
            )

    # World-writable check on /tmp style (informational)
    world_writable = []
    for d in ("/tmp", "/var/tmp"):
        p = Path(d)
        if p.exists():
            try:
                mode = stat.S_IMODE(p.stat().st_mode)
                if mode & stat.S_IWOTH:
                    world_writable.append(d)
            except OSError:
                pass

    findings.append(
        make_finding(
            module="permissions",
            check_id="perm.world_writable_tmp",
            title="World-writable temporary directories",
            description=f"World-writable: {', '.join(world_writable) or 'none of /tmp,/var/tmp'}",
            current=", ".join(world_writable) or "none",
            expected="/tmp and /var/tmp typically sticky+world-writable",
            severity=Severity.INFO,
            state=AuditState.PASS,
            risk="Expected for temporary directories when sticky bit is set.",
            recommendation="Ensure sticky bit (chmod +t) is set on world-writable temp dirs.",
            evidence=str(world_writable),
        )
    )

    return findings
