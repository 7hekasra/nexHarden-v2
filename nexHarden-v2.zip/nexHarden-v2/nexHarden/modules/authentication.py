"""Authentication and PAM-related checks (read-only)."""

from __future__ import annotations

from pathlib import Path
from typing import List

from core.risk_engine import AuditState, Finding, Severity, make_finding
from core.system import SystemInfo


def audit(system: SystemInfo, full: bool = False) -> List[Finding]:
    findings: List[Finding] = []

    # Check for common PAM password quality modules
    pam_passwd = Path("/etc/pam.d/common-password")
    if pam_passwd.exists():
        try:
            content = pam_passwd.read_text(encoding="utf-8")
            has_quality = "pam_pwquality" in content or "pam_cracklib" in content
            findings.append(
                make_finding(
                    module="authentication",
                    check_id="auth.password_quality",
                    title="Password quality module",
                    description="Checked common-password PAM stack.",
                    current="present" if has_quality else "not detected",
                    expected="pam_pwquality or equivalent",
                    severity=Severity.LOW if not has_quality else Severity.INFO,
                    state=AuditState.PASS if has_quality else AuditState.WARNING,
                    risk="Weak password policy allows easily guessable passwords.",
                    recommendation="Configure pam_pwquality.so with appropriate minlen and complexity.",
                    evidence="common-password content inspected (no secrets)",
                )
            )
        except OSError:
            findings.append(
                make_finding(
                    module="authentication",
                    check_id="auth.password_quality",
                    title="Password quality module",
                    description="Could not read PAM configuration.",
                    current="unavailable",
                    expected="readable",
                    severity=Severity.INFO,
                    state=AuditState.UNKNOWN,
                    risk="",
                    recommendation="",
                )
            )
    else:
        findings.append(
            make_finding(
                module="authentication",
                check_id="auth.password_quality",
                title="Password quality module",
                description="/etc/pam.d/common-password not found.",
                current="missing",
                expected="present on Debian/Ubuntu",
                severity=Severity.INFO,
                state=AuditState.NA,
                risk="",
                recommendation="",
            )
        )

    # Login.defs password aging
    login_defs = Path("/etc/login.defs")
    if login_defs.exists():
        try:
            content = login_defs.read_text(encoding="utf-8")
            pass_max_days = None
            for line in content.splitlines():
                if line.strip().startswith("PASS_MAX_DAYS"):
                    parts = line.split()
                    if len(parts) >= 2:
                        pass_max_days = parts[1]
            if pass_max_days and pass_max_days.isdigit():
                days = int(pass_max_days)
                ok = 0 < days <= 365
                findings.append(
                    make_finding(
                        module="authentication",
                        check_id="auth.pass_max_days",
                        title="Password maximum age",
                        description=f"PASS_MAX_DAYS = {days}",
                        current=str(days),
                        expected="1-365 (policy dependent)",
                        severity=Severity.LOW if not ok else Severity.INFO,
                        state=AuditState.PASS if ok else AuditState.WARNING,
                        risk="Very long or zero max age weakens password rotation policy.",
                        recommendation="Set PASS_MAX_DAYS to an organization-appropriate value (e.g. 90-365).",
                        evidence=f"login.defs PASS_MAX_DAYS={days}",
                    )
                )
        except OSError:
            pass

    # faillock / tally presence (informational)
    faillock = Path("/etc/security/faillock.conf")
    findings.append(
        make_finding(
            module="authentication",
            check_id="auth.lockout",
            title="Account lockout configuration",
            description="Checked for faillock configuration.",
            current="present" if faillock.exists() else "not found",
            expected="configured lockout policy",
            severity=Severity.INFO,
            state=AuditState.PASS if faillock.exists() else AuditState.WARNING,
            risk="Without lockout, online brute-force is unconstrained at the PAM level.",
            recommendation="Configure pam_faillock or equivalent lockout policy.",
            evidence=str(faillock),
        )
    )

    return findings
