"""Package and update security audit (APT)."""

from __future__ import annotations

from pathlib import Path
from typing import List

from core.risk_engine import AuditState, Finding, Severity, make_finding
from core.system import SystemInfo
from core.validators import run_cmd


def audit(system: SystemInfo, full: bool = False) -> List[Finding]:
    findings: List[Finding] = []

    if system.package_manager != "apt":
        findings.append(
            make_finding(
                module="packages",
                check_id="pkg.manager",
                title="Package manager",
                description=f"Package manager is '{system.package_manager}', not APT.",
                current=system.package_manager,
                expected="apt",
                severity=Severity.INFO,
                state=AuditState.NA,
                risk="Package security checks are limited on non-APT systems.",
                recommendation="",
            )
        )
        return findings

    # Check for unattended-upgrades
    uau = Path("/etc/apt/apt.conf.d/20auto-upgrades")
    uu_enabled = False
    if uau.exists():
        try:
            content = uau.read_text(encoding="utf-8")
            if 'APT::Periodic::Unattended-Upgrade "1"' in content or \
               'APT::Periodic::Unattended-Upgrade "1";' in content:
                uu_enabled = True
        except OSError:
            pass

    # Also check package presence
    code, out, _ = run_cmd(["dpkg", "-l", "unattended-upgrades"])
    pkg_installed = code == 0 and "ii" in out

    if uu_enabled and pkg_installed:
        findings.append(
            make_finding(
                module="packages",
                check_id="pkg.unattended_upgrades",
                title="Unattended upgrades",
                description="Unattended-upgrades appears enabled.",
                current="enabled",
                expected="enabled for security updates",
                severity=Severity.INFO,
                state=AuditState.PASS,
                risk="",
                recommendation="",
                evidence="20auto-upgrades and package present",
            )
        )
    else:
        findings.append(
            make_finding(
                module="packages",
                check_id="pkg.unattended_upgrades",
                title="Unattended upgrades",
                description="Automatic security updates may not be configured.",
                current="disabled or incomplete",
                expected="enabled",
                severity=Severity.MEDIUM,
                state=AuditState.WARNING,
                risk="Missing automatic updates delays patching of known vulnerabilities.",
                recommendation="Install and enable unattended-upgrades for security updates.",
                evidence=f"package_installed={pkg_installed}, config_enabled={uu_enabled}",
            )
        )

    # Pending updates (simulation, non-destructive)
    if system.is_root or True:  # apt-get -s works for non-root often
        code, out, err = run_cmd(
            ["apt-get", "-s", "upgrade"], timeout=60
        )
        if code == 0:
            upgradable = [
                line for line in out.splitlines()
                if line.startswith("Inst ")
            ]
            count = len(upgradable)
            if count == 0:
                findings.append(
                    make_finding(
                        module="packages",
                        check_id="pkg.pending_updates",
                        title="Pending package upgrades",
                        description="No pending upgrades detected (simulation).",
                        current="0",
                        expected="0 or promptly applied",
                        severity=Severity.INFO,
                        state=AuditState.PASS,
                        risk="",
                        recommendation="",
                        evidence="apt-get -s upgrade",
                    )
                )
            else:
                findings.append(
                    make_finding(
                        module="packages",
                        check_id="pkg.pending_updates",
                        title="Pending package upgrades",
                        description=f"{count} package(s) can be upgraded.",
                        current=str(count),
                        expected="0 (or apply promptly)",
                        severity=Severity.MEDIUM if count > 5 else Severity.LOW,
                        state=AuditState.WARNING,
                        risk="Unapplied updates may leave known vulnerabilities unpatched.",
                        recommendation="Review and apply security updates: sudo apt update && sudo apt upgrade",
                        evidence="\n".join(upgradable[:10]),
                    )
                )
        else:
            findings.append(
                make_finding(
                    module="packages",
                    check_id="pkg.pending_updates",
                    title="Pending package upgrades",
                    description="Could not simulate upgrade.",
                    current="unknown",
                    expected="checkable",
                    severity=Severity.INFO,
                    state=AuditState.UNKNOWN,
                    risk="",
                    recommendation="Run: sudo apt update",
                    evidence=err[:200],
                )
            )

    return findings
