"""User and privilege audit module."""

from __future__ import annotations

import os
from pathlib import Path
from typing import List

from core.risk_engine import AuditState, Finding, Severity, make_finding
from core.system import SystemInfo


def audit(system: SystemInfo, full: bool = False) -> List[Finding]:
    findings: List[Finding] = []

    # UID 0 accounts
    uid0 = []
    try:
        with open("/etc/passwd", "r", encoding="utf-8") as fh:
            for line in fh:
                parts = line.strip().split(":")
                if len(parts) >= 7 and parts[2] == "0":
                    uid0.append(parts[0])
    except OSError:
        findings.append(
            make_finding(
                module="users",
                check_id="users.uid0",
                title="UID 0 accounts",
                description="Could not read /etc/passwd.",
                current="unavailable",
                expected="only root",
                severity=Severity.MEDIUM,
                state=AuditState.UNKNOWN,
                risk="Cannot verify privileged accounts.",
                recommendation="Ensure /etc/passwd is readable by the auditor.",
            )
        )
        return findings

    if uid0 == ["root"]:
        findings.append(
            make_finding(
                module="users",
                check_id="users.uid0",
                title="UID 0 accounts",
                description="Only the root account has UID 0.",
                current="root",
                expected="only root",
                severity=Severity.INFO,
                state=AuditState.PASS,
                risk="",
                recommendation="",
                evidence="UID 0: root",
            )
        )
    else:
        findings.append(
            make_finding(
                module="users",
                check_id="users.uid0",
                title="Multiple UID 0 accounts",
                description=f"UID 0 accounts: {', '.join(uid0)}",
                current=", ".join(uid0),
                expected="only root",
                severity=Severity.HIGH,
                state=AuditState.FAIL,
                risk="Additional UID 0 accounts increase privilege escalation risk.",
                recommendation="Remove or demote unexpected UID 0 accounts.",
                evidence=f"UID 0 accounts: {uid0}",
            )
        )

    # Interactive shell accounts
    interactive_shells = {"/bin/bash", "/bin/sh", "/bin/zsh", "/usr/bin/bash", "/usr/bin/zsh", "/bin/dash"}
    interactive = []
    try:
        with open("/etc/passwd", "r", encoding="utf-8") as fh:
            for line in fh:
                parts = line.strip().split(":")
                if len(parts) >= 7 and parts[6] in interactive_shells:
                    interactive.append(parts[0])
    except OSError:
        pass

    findings.append(
        make_finding(
            module="users",
            check_id="users.interactive",
            title="Accounts with interactive shells",
            description=f"{len(interactive)} accounts have interactive shells.",
            current=str(len(interactive)),
            expected="minimal necessary set",
            severity=Severity.INFO,
            state=AuditState.PASS,
            risk="Unused interactive accounts expand the attack surface.",
            recommendation="Lock or remove unused interactive accounts.",
            evidence=", ".join(interactive[:20]),
        )
    )

    # Sudo group
    sudo_members = []
    for group_file in ("/etc/group",):
        try:
            with open(group_file, "r", encoding="utf-8") as fh:
                for line in fh:
                    if line.startswith("sudo:") or line.startswith("wheel:"):
                        parts = line.strip().split(":")
                        if len(parts) >= 4 and parts[3]:
                            sudo_members = parts[3].split(",")
        except OSError:
            pass

    findings.append(
        make_finding(
            module="users",
            check_id="users.sudo_members",
            title="Sudo/wheel group members",
            description=f"Members: {', '.join(sudo_members) if sudo_members else '(none detected)'}",
            current=", ".join(sudo_members) if sudo_members else "none",
            expected="minimal trusted administrators",
            severity=Severity.INFO,
            state=AuditState.PASS,
            risk="Broad sudo membership increases lateral movement impact.",
            recommendation="Review sudoers and group membership regularly.",
            evidence=f"sudo/wheel: {sudo_members}",
        )
    )

    # Empty password detection (shadow) - only if root
    if system.is_root:
        empty_pw = []
        try:
            with open("/etc/shadow", "r", encoding="utf-8") as fh:
                for line in fh:
                    parts = line.strip().split(":")
                    if len(parts) >= 2 and parts[1] == "":
                        empty_pw.append(parts[0])
        except OSError:
            pass
        if empty_pw:
            findings.append(
                make_finding(
                    module="users",
                    check_id="users.empty_password",
                    title="Accounts with empty password field",
                    description=f"Accounts: {', '.join(empty_pw)}",
                    current=", ".join(empty_pw),
                    expected="none",
                    severity=Severity.CRITICAL,
                    state=AuditState.FAIL,
                    risk="Empty password fields may allow unauthenticated login depending on PAM.",
                    recommendation="Set passwords or lock these accounts immediately.",
                    evidence="shadow password field empty (hashes not shown)",
                )
            )
        else:
            findings.append(
                make_finding(
                    module="users",
                    check_id="users.empty_password",
                    title="Empty password fields",
                    description="No accounts with empty password field detected.",
                    current="none",
                    expected="none",
                    severity=Severity.INFO,
                    state=AuditState.PASS,
                    risk="",
                    recommendation="",
                    evidence="Checked /etc/shadow",
                )
            )
    else:
        findings.append(
            make_finding(
                module="users",
                check_id="users.empty_password",
                title="Empty password check",
                description="Requires root to inspect /etc/shadow.",
                current="skipped",
                expected="no empty passwords",
                severity=Severity.INFO,
                state=AuditState.UNKNOWN,
                risk="Cannot verify without elevated privileges.",
                recommendation="Re-run audit with sudo for full user checks.",
            )
        )

    return findings
