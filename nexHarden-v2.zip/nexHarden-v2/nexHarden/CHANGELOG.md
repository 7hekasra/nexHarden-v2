# Changelog

## [1.0.0] — 2026-11-03

### Added

- Initial public release of nexHarden.
- Core engine: system detection, module loader, scoring, risk engine.
- Audit modules: ssh, firewall, users, permissions, kernel, network, packages, authentication, logging, services, filesystem.
- Hardening profiles: basic, standard, strict (sysctl-focused).
- Safe executor with dry-run default, transaction backups, and rollback.
- Self-contained HTML dashboard with filtering and detail views.
- JSON report format.
- Local audit history.
- CLI: audit, harden, backup, rollback, history, system-info, version.
- Documentation: README.md, README.fa.md, SECURITY.md, LICENSE.
- Automated unit tests for scoring, system detection helpers, HTML escaping, and safety behaviors.

### Security

- No automatic SSH or firewall rule modification.
- Reports written with restrictive permissions.
- HTML output escaped to reduce XSS risk from report data.
- Subprocess calls use argument lists (no shell interpolation).

### Known Limitations

- Hardening applies runtime sysctl only; persistence to sysctl.d is left to the administrator or future releases.
- Some checks require root for full accuracy.
- Primary support matrix: Debian 12/13, Ubuntu 22.04/24.04.
