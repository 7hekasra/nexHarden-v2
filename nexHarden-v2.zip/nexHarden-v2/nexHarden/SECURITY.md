# Security Policy — nexHarden 1.0.0

## Security Model

nexHarden is designed around these guarantees:

1. **Audit is read-only.** Running `audit` does not modify system configuration.
2. **Hardening requires explicit approval.** Dry-run is the default. `--apply` still prompts unless `--yes` is used, and even then backups are mandatory.
3. **Smallest possible change.** Only settings declared in the selected profile are touched.
4. **Backups before modification.** Every apply creates a timestamped transaction with file copies and metadata.
5. **Rollback safety.** Restore is refused if the current file does not match the post-hardening hash (unexpected user edits are preserved).
6. **No telemetry.** No network calls, no uploads, no remote command execution.
7. **No secret collection.** Password hashes, private keys, and authentication secrets are never written to reports.

## Privilege Model

| Operation | Privileges |
|-----------|------------|
| Basic audit | Unprivileged (some checks limited) |
| Full user/shadow checks | Root |
| Sysctl hardening | Root |
| Backup / rollback of system files | Root |

The tool clearly indicates when root is required.

## Backup Behavior

- Backups live under `backups/<transaction_id>/`.
- Original content, SHA-256, ownership, and mode are recorded.
- Transaction JSON is mode 0600.

## Rollback Limitations

- Only files recorded in the transaction are restored.
- Runtime sysctl values that were not persisted to `/etc/sysctl.d/` may need re-application or reboot handling by the administrator.
- Rollback will not overwrite files that changed after the hardening transaction.

## Reporting Privacy

Reports (HTML/JSON) may include:

- Hostnames, interface names, package names
- Configuration values (non-secret)
- Listening port counts

They must **not** contain:

- Passwords or password hashes
- Private SSH keys
- Full authentication logs with usernames/IPs beyond what is necessary for evidence

Treat report files as sensitive. Default permissions are restrictive.

## SSH and Firewall Safety

In 1.0.0, nexHarden **does not** automatically edit `sshd_config` or install firewall rules. These modules are audit-only. Automatic modification is deferred until stronger recovery guarantees (console access detection, alternate port, validated reload) are implemented.

## Responsible Disclosure

If you discover a vulnerability in nexHarden itself (for example, path traversal in backup paths, unsafe subprocess usage, or XSS in the HTML report), please report it privately to the maintainers. Do not open a public issue with exploit details until a fix is available.

## Disclaimer

nexHarden does not claim that any system is fully secure. It is a configuration auditing and controlled hardening aid, not a substitute for threat modeling, patch management, monitoring, or professional security assessment.
