#!/usr/bin/env bash
# nexHarden launcher helper
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$DIR/nexharden" "$@"
