#!/usr/bin/env python3
"""Tests for backup and rollback (uses temporary directories)."""

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.backup import BackupManager
from core.rollback import RollbackManager


def test_backup_and_rollback():
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        backup_dir = tmp / "backups"
        work = tmp / "work"
        work.mkdir()

        target = work / "config.txt"
        target.write_text("original content\n", encoding="utf-8")

        bm = BackupManager(backup_dir)
        record = bm.create_transaction(
            profile="test",
            description="unit test",
            files=[target],
        )
        tx_id = record["transaction_id"]
        assert tx_id
        assert str(target) in record["files"]

        # Simulate hardening change
        target.write_text("modified content\n", encoding="utf-8")
        bm.record_change(tx_id, str(target), "modified", "test change")
        bm.finalize(tx_id, status="applied")

        # Reload and check meta_after
        rec = bm.load_transaction(tx_id)
        assert rec["status"] == "applied"
        assert "meta_after" in rec["files"][str(target)]

        rm = RollbackManager(bm)
        preview = rm.preview(tx_id)
        assert preview.get("safe") is True

        ok, msg, restored = rm.rollback(tx_id, confirm=True)
        assert ok, msg
        assert target.read_text(encoding="utf-8") == "original content\n"
        print("  backup/rollback cycle ok")


def test_rollback_refuses_modified():
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        bm = BackupManager(tmp / "backups")
        work = tmp / "work"
        work.mkdir()
        target = work / "f.txt"
        target.write_text("v1\n", encoding="utf-8")

        rec = bm.create_transaction("test", files=[target])
        tx = rec["transaction_id"]
        target.write_text("v2\n", encoding="utf-8")
        bm.finalize(tx, "applied")

        # User modifies again
        target.write_text("user edit\n", encoding="utf-8")

        rm = RollbackManager(bm)
        preview = rm.preview(tx)
        assert preview.get("safe") is False
        ok, msg, _ = rm.rollback(tx, confirm=True)
        assert not ok
        assert "refused" in msg.lower() or "safety" in msg.lower()
        print("  safety refusal ok")


if __name__ == "__main__":
    test_backup_and_rollback()
    test_rollback_refuses_modified()
    print("test_backup: all passed")
