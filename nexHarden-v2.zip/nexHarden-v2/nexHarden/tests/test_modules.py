#!/usr/bin/env python3
"""Smoke tests for audit modules (read-only)."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.system import SystemDetector
from core.risk_engine import Finding


def test_modules_import_and_run():
    det = SystemDetector()
    info = det.detect()
    modules = [
        "ssh", "firewall", "users", "permissions", "kernel",
        "network", "packages", "authentication", "logging",
        "services", "filesystem",
    ]
    for name in modules:
        mod = __import__(f"modules.{name}", fromlist=["audit"])
        assert hasattr(mod, "audit")
        results = mod.audit(info, full=False)
        assert isinstance(results, list)
        for f in results:
            assert isinstance(f, Finding)
            assert f.module == name
        print(f"  {name}: {len(results)} findings")


if __name__ == "__main__":
    test_modules_import_and_run()
    print("test_modules: all passed")
