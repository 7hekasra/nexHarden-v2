#!/usr/bin/env python3
"""Safety and HTML escaping tests."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.reporter import Reporter
from core.validators import is_safe_path


def test_html_escape():
    assert Reporter.escape("<script>alert(1)</script>") == "&lt;script&gt;alert(1)&lt;/script&gt;"
    assert Reporter.escape('a&b"c') == "a&amp;b&quot;c"
    print("  html escape ok")


def test_safe_path():
    assert is_safe_path(Path("/etc/ssh/sshd_config")) is True
    assert is_safe_path(Path("/proc/self/mem")) is False
    assert is_safe_path(Path("/sys/kernel")) is False
    print("  path safety ok")


def test_dry_run_default_in_executor():
    from core.backup import BackupManager
    from core.executor import Executor
    from core.logger import StructuredLogger
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        bm = BackupManager(Path(tmp) / "b")
        log = StructuredLogger(Path(tmp) / "l")
        ex = Executor(bm, log, dry_run=True)
        assert ex.dry_run is True
    print("  dry-run default ok")


if __name__ == "__main__":
    test_html_escape()
    test_safe_path()
    test_dry_run_default_in_executor()
    print("test_safety: all passed")
