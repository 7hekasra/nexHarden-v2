#!/usr/bin/env python3
"""Tests for scoring engine."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.risk_engine import AuditState, Finding, Severity, make_finding
from core.scoring import calculate_score


def test_all_pass():
    findings = [
        make_finding("m", "c1", "t", "d", "a", "a", Severity.HIGH, AuditState.PASS, "", ""),
        make_finding("m", "c2", "t", "d", "a", "a", Severity.MEDIUM, AuditState.PASS, "", ""),
    ]
    r = calculate_score(findings)
    assert r.score == 100.0
    assert r.passed == 2
    assert r.failed == 0


def test_critical_fail():
    findings = [
        make_finding("m", "c1", "t", "d", "bad", "good", Severity.CRITICAL, AuditState.FAIL, "r", "rec"),
        make_finding("m", "c2", "t", "d", "a", "a", Severity.LOW, AuditState.PASS, "", ""),
    ]
    r = calculate_score(findings)
    # CRITICAL weight 10, LOW weight 1 → earned 1 / possible 11
    assert abs(r.score - (1 / 11 * 100)) < 0.1
    assert r.critical == 1


def test_unknown_excluded():
    findings = [
        make_finding("m", "c1", "t", "d", "?", "x", Severity.HIGH, AuditState.UNKNOWN, "", ""),
        make_finding("m", "c2", "t", "d", "a", "a", Severity.HIGH, AuditState.PASS, "", ""),
    ]
    r = calculate_score(findings)
    assert r.score == 100.0
    assert r.unknown == 1
    assert r.evaluated == 1


def test_warning_no_points():
    findings = [
        make_finding("m", "c1", "t", "d", "x", "y", Severity.MEDIUM, AuditState.WARNING, "r", "rec"),
        make_finding("m", "c2", "t", "d", "a", "a", Severity.MEDIUM, AuditState.PASS, "", ""),
    ]
    r = calculate_score(findings)
    # WARNING does not add to possible; only PASS counts
    assert r.score == 100.0
    assert r.warnings == 1


def test_na_excluded():
    findings = [
        make_finding("m", "c1", "t", "d", "n/a", "x", Severity.HIGH, AuditState.NA, "", ""),
    ]
    r = calculate_score(findings)
    assert r.na == 1
    assert r.score == 100.0  # nothing failed


if __name__ == "__main__":
    test_all_pass()
    test_critical_fail()
    test_unknown_excluded()
    test_warning_no_points()
    test_na_excluded()
    print("test_scoring: all passed")
