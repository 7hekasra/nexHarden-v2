#!/usr/bin/env python3
"""Tests for system detection (non-destructive)."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core.system import SystemDetector, SystemInfo


def test_detect_runs():
    det = SystemDetector()
    info = det.detect()
    assert isinstance(info, SystemInfo)
    assert info.hostname
    assert info.kernel
    assert info.architecture
    assert info.distribution_id
    print(f"  detected: {info.distribution} {info.version} ({info.architecture})")


def test_to_dict():
    det = SystemDetector()
    info = det.detect()
    d = info.to_dict()
    assert "hostname" in d
    assert "is_supported" in d


if __name__ == "__main__":
    test_detect_runs()
    test_to_dict()
    print("test_system: all passed")
