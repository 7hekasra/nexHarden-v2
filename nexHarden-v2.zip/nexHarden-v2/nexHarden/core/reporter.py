"""Report generation: JSON and HTML dashboard."""

from __future__ import annotations

import html
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from .risk_engine import Finding
from .scoring import ScoreResult
from .system import SystemInfo


class Reporter:
    """Generates JSON and self-contained HTML reports."""

    def __init__(
        self,
        report_dir: Path,
        dashboard_dir: Path,
        version: str = "1.0.0",
    ) -> None:
        self.report_dir = Path(report_dir)
        self.dashboard_dir = Path(dashboard_dir)
        self.version = version
        self.report_dir.mkdir(parents=True, exist_ok=True)

    def build_report_data(
        self,
        audit_id: str,
        system: SystemInfo,
        findings: List[Finding],
        score: ScoreResult,
        modules_run: List[str],
        duration: float,
        errors: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        return {
            "nexharden_version": self.version,
            "audit_id": audit_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "duration_seconds": round(duration, 2),
            "system": system.to_dict(),
            "modules_executed": modules_run,
            "score": score.to_dict(),
            "findings": [f.to_dict() for f in findings],
            "errors": errors or [],
            "summary": {
                "total_findings": len(findings),
                "critical": score.critical,
                "high": score.high,
                "medium": score.medium,
                "low": score.low,
                "passed": score.passed,
                "warnings": score.warnings,
                "unknown": score.unknown,
                "na": score.na,
            },
        }

    def write_json(self, data: Dict[str, Any], filename: Optional[str] = None) -> Path:
        if not filename:
            filename = f"audit-{data['audit_id']}.json"
        path = self.report_dir / filename
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return path

    def write_html(self, data: Dict[str, Any], filename: Optional[str] = None) -> Path:
        if not filename:
            filename = f"audit-{data['audit_id']}.html"
        path = self.report_dir / filename

        template_path = self.dashboard_dir / "template.html"
        css_path = self.dashboard_dir / "style.css"
        js_path = self.dashboard_dir / "app.js"

        css = ""
        js = ""
        if css_path.exists():
            css = css_path.read_text(encoding="utf-8")
        if js_path.exists():
            js = js_path.read_text(encoding="utf-8")

        # Embed data safely
        json_data = json.dumps(data, ensure_ascii=False)
        # Escape for embedding inside <script>
        json_data_safe = json_data.replace("</", "<\\/")

        if template_path.exists():
            tpl = template_path.read_text(encoding="utf-8")
            html_content = (
                tpl.replace("/*{{CSS}}*/", css)
                .replace("/*{{JS}}*/", js)
                .replace("/*{{DATA}}*/", json_data_safe)
            )
        else:
            # Minimal fallback
            html_content = self._fallback_html(data, css, js, json_data_safe)

        with open(path, "w", encoding="utf-8") as fh:
            fh.write(html_content)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return path

    def _fallback_html(
        self, data: Dict, css: str, js: str, json_data: str
    ) -> str:
        score = data.get("score", {})
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>nexHarden Report</title>
<style>{css}</style>
</head>
<body>
<div id="app">
  <header><h1>nexHarden</h1>
  <p>Linux Security Auditing &amp; Hardening Framework</p></header>
  <section class="score">
    <h2>Configuration Compliance Score: {score.get('score', 'N/A')}</h2>
    <p>Coverage: {score.get('coverage', 'N/A')}%</p>
  </section>
  <pre id="raw"></pre>
</div>
<script>
const REPORT_DATA = {json_data};
document.getElementById('raw').textContent = JSON.stringify(REPORT_DATA, null, 2);
{js}
</script>
</body>
</html>"""

    @staticmethod
    def escape(value: Any) -> str:
        return html.escape(str(value) if value is not None else "")
