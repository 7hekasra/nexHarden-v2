"""Main audit and hardening engine."""

from __future__ import annotations

import importlib
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Type

from .backup import BackupManager
from .config import Config
from .executor import Executor
from .logger import StructuredLogger
from .reporter import Reporter
from .risk_engine import Finding
from .rollback import RollbackManager
from .scoring import ScoreResult, calculate_score
from .system import SystemDetector, SystemInfo


# Module registry
AVAILABLE_MODULES = [
    "ssh",
    "firewall",
    "users",
    "permissions",
    "kernel",
    "network",
    "packages",
    "authentication",
    "logging",
    "services",
    "filesystem",
]


class AuditEngine:
    """Orchestrates system detection, module execution, scoring, and reporting."""

    def __init__(self, project_root: Optional[Path] = None) -> None:
        self.config = Config(project_root)
        self.logger = StructuredLogger(self.config.log_dir)
        self.system_info: Optional[SystemInfo] = None
        self.findings: List[Finding] = []
        self.errors: List[str] = []
        self.modules_run: List[str] = []

    def detect_system(self) -> SystemInfo:
        detector = SystemDetector()
        self.system_info = detector.detect()
        return self.system_info

    def run_audit(
        self,
        modules: Optional[List[str]] = None,
        full: bool = False,
    ) -> Dict[str, Any]:
        start = time.time()
        audit_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + str(uuid.uuid4())[:8]

        self.logger.audit_start(audit_id)
        self.findings = []
        self.errors = []
        self.modules_run = []

        if self.system_info is None:
            self.detect_system()

        assert self.system_info is not None

        if not self.system_info.is_supported:
            for note in self.system_info.support_notes:
                self.logger.warning(note)

        target_modules = modules or AVAILABLE_MODULES
        if not full and modules is None:
            # Default set for non-full audit
            target_modules = [
                "ssh", "firewall", "users", "permissions",
                "kernel", "network", "packages", "services",
            ]

        for mod_name in target_modules:
            if mod_name not in AVAILABLE_MODULES:
                self.errors.append(f"Unknown module: {mod_name}")
                continue
            try:
                mod = importlib.import_module(f"modules.{mod_name}")
                if hasattr(mod, "audit"):
                    result = mod.audit(self.system_info, full=full)
                    if isinstance(result, list):
                        self.findings.extend(result)
                    self.modules_run.append(mod_name)
                    self.logger.info(f"Module {mod_name} completed", module=mod_name)
                else:
                    self.errors.append(f"Module {mod_name} has no audit() function")
            except Exception as exc:  # noqa: BLE001
                msg = f"Module {mod_name} failed: {exc}"
                self.errors.append(msg)
                self.logger.error(msg, module=mod_name)

        score = calculate_score(self.findings)
        duration = time.time() - start

        self.logger.audit_end(audit_id, duration, len(self.findings))

        reporter = Reporter(
            self.config.report_dir,
            self.config.project_root / "dashboard",
            version="1.0.0",
        )
        data = reporter.build_report_data(
            audit_id=audit_id,
            system=self.system_info,
            findings=self.findings,
            score=score,
            modules_run=self.modules_run,
            duration=duration,
            errors=self.errors,
        )

        # Persist history
        if self.config.get("history_enabled", True):
            self._save_history(data)

        return data

    def generate_reports(
        self, data: Dict[str, Any], formats: List[str]
    ) -> Dict[str, Path]:
        reporter = Reporter(
            self.config.report_dir,
            self.config.project_root / "dashboard",
            version="1.0.0",
        )
        paths: Dict[str, Path] = {}
        if "json" in formats:
            paths["json"] = reporter.write_json(data)
        if "html" in formats:
            paths["html"] = reporter.write_html(data)
        return paths

    def _save_history(self, data: Dict[str, Any]) -> None:
        hist_dir = self.config.history_dir
        path = hist_dir / f"{data['audit_id']}.json"
        try:
            import json
            with open(path, "w", encoding="utf-8") as fh:
                # Store a summary for history
                summary = {
                    "audit_id": data["audit_id"],
                    "timestamp": data["timestamp"],
                    "score": data["score"],
                    "summary": data["summary"],
                    "system": {
                        "hostname": data["system"].get("hostname"),
                        "distribution": data["system"].get("distribution"),
                        "version": data["system"].get("version"),
                    },
                }
                json.dump(summary, fh, indent=2)
        except OSError:
            pass

    def list_history(self) -> List[Dict[str, Any]]:
        hist_dir = self.config.history_dir
        results = []
        if not hist_dir.exists():
            return results
        import json
        for p in sorted(hist_dir.glob("*.json"), reverse=True):
            try:
                with open(p, "r", encoding="utf-8") as fh:
                    results.append(json.load(fh))
            except (OSError, json.JSONDecodeError):
                continue
        return results
