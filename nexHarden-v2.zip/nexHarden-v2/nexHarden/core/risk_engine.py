"""Risk engine: findings, severity, and structured results."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, List, Optional


class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


class AuditState(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    WARNING = "WARNING"
    UNKNOWN = "UNKNOWN"
    NA = "N/A"


@dataclass
class Finding:
    """A single audit finding."""

    id: str
    module: str
    title: str
    description: str
    current_value: str
    expected_value: str
    severity: Severity
    state: AuditState
    risk_explanation: str
    recommendation: str
    auto_fixable: bool = False
    manual_required: bool = True
    confidence: str = "high"  # high, medium, low
    evidence: str = ""
    references: List[str] = field(default_factory=list)
    check_id: str = ""

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["severity"] = self.severity.value
        d["state"] = self.state.value
        return d


def make_finding(
    module: str,
    check_id: str,
    title: str,
    description: str,
    current: str,
    expected: str,
    severity: Severity,
    state: AuditState,
    risk: str,
    recommendation: str,
    auto_fixable: bool = False,
    manual: bool = True,
    confidence: str = "high",
    evidence: str = "",
    references: Optional[List[str]] = None,
) -> Finding:
    return Finding(
        id=str(uuid.uuid4())[:8],
        module=module,
        title=title,
        description=description,
        current_value=str(current),
        expected_value=str(expected),
        severity=severity,
        state=state,
        risk_explanation=risk,
        recommendation=recommendation,
        auto_fixable=auto_fixable,
        manual_required=manual,
        confidence=confidence,
        evidence=evidence,
        references=references or [],
        check_id=check_id,
    )
