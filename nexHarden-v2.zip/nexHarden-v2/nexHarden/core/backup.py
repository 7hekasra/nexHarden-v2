"""Backup management for hardening transactions."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import stat
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import uuid4


class BackupManager:
    """Creates and manages timestamped backups of files before modification."""

    def __init__(self, backup_dir: Path) -> None:
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    def _hash_file(self, path: Path) -> str:
        h = hashlib.sha256()
        try:
            with open(path, "rb") as fh:
                for chunk in iter(lambda: fh.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except OSError:
            return ""

    def _file_meta(self, path: Path) -> Dict[str, Any]:
        try:
            st = path.stat()
            return {
                "size": st.st_size,
                "mode": stat.filemode(st.st_mode),
                "uid": st.st_uid,
                "gid": st.st_gid,
                "mtime": st.st_mtime,
                "sha256": self._hash_file(path),
            }
        except OSError as exc:
            return {"error": str(exc)}

    def create_transaction(
        self,
        profile: str,
        description: str = "",
        files: Optional[List[Path]] = None,
    ) -> Dict[str, Any]:
        """Create a new transaction record and back up the listed files."""
        tx_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + str(uuid4())[:8]
        tx_dir = self.backup_dir / tx_id
        tx_dir.mkdir(parents=True, exist_ok=True)

        record: Dict[str, Any] = {
            "transaction_id": tx_id,
            "profile": profile,
            "description": description,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "files": {},
            "status": "created",
            "changes": [],
        }

        if files:
            for src in files:
                src = Path(src)
                if not src.exists():
                    continue
                # Preserve relative structure under a safe name
                safe_name = str(src).lstrip("/").replace("/", "_")
                dest = tx_dir / safe_name
                try:
                    shutil.copy2(src, dest)
                    record["files"][str(src)] = {
                        "backup_path": str(dest),
                        "meta_before": self._file_meta(src),
                    }
                except OSError as exc:
                    record["files"][str(src)] = {"error": str(exc)}

        self._write_record(tx_id, record)
        return record

    def record_change(
        self, tx_id: str, path: str, action: str, detail: str = ""
    ) -> None:
        record = self.load_transaction(tx_id)
        if not record:
            return
        record.setdefault("changes", []).append(
            {
                "path": path,
                "action": action,
                "detail": detail,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        )
        self._write_record(tx_id, record)

    def finalize(self, tx_id: str, status: str = "applied") -> None:
        record = self.load_transaction(tx_id)
        if not record:
            return
        record["status"] = status
        record["finalized_at"] = datetime.now(timezone.utc).isoformat()
        # Capture post-change metadata
        for path, info in record.get("files", {}).items():
            p = Path(path)
            if p.exists():
                info["meta_after"] = self._file_meta(p)
        self._write_record(tx_id, record)

    def load_transaction(self, tx_id: str) -> Optional[Dict[str, Any]]:
        path = self.backup_dir / tx_id / "transaction.json"
        if not path.exists():
            return None
        try:
            with open(path, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except (OSError, json.JSONDecodeError):
            return None

    def list_transactions(self) -> List[Dict[str, Any]]:
        results = []
        if not self.backup_dir.exists():
            return results
        for d in sorted(self.backup_dir.iterdir(), reverse=True):
            if d.is_dir():
                rec = self.load_transaction(d.name)
                if rec:
                    results.append(
                        {
                            "transaction_id": rec.get("transaction_id"),
                            "profile": rec.get("profile"),
                            "created_at": rec.get("created_at"),
                            "status": rec.get("status"),
                            "description": rec.get("description", ""),
                            "file_count": len(rec.get("files", {})),
                        }
                    )
        return results

    def _write_record(self, tx_id: str, record: Dict[str, Any]) -> None:
        path = self.backup_dir / tx_id / "transaction.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(record, fh, indent=2, ensure_ascii=False)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
