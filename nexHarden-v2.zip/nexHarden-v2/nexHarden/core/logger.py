"""Structured logging for nexHarden."""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional


class StructuredLogger:
    """Simple structured logger that writes JSON lines and human-readable text."""

    def __init__(self, log_dir: Path, name: str = "nexharden") -> None:
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.name = name
        self._logger = logging.getLogger(name)
        self._logger.setLevel(logging.DEBUG)
        self._logger.handlers.clear()

        # Human-readable log
        text_handler = logging.FileHandler(
            self.log_dir / f"{name}.log", encoding="utf-8"
        )
        text_handler.setFormatter(
            logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
        )
        self._logger.addHandler(text_handler)

        # Also log to console at INFO
        console = logging.StreamHandler()
        console.setLevel(logging.INFO)
        console.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
        self._logger.addHandler(console)

        self.json_path = self.log_dir / f"{name}.jsonl"

    def _write_json(self, level: str, message: str, **extra: Any) -> None:
        record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "level": level,
            "message": message,
            **extra,
        }
        try:
            with open(self.json_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(record, ensure_ascii=False) + "\n")
        except OSError:
            pass

    def info(self, message: str, **extra: Any) -> None:
        self._logger.info(message)
        self._write_json("INFO", message, **extra)

    def warning(self, message: str, **extra: Any) -> None:
        self._logger.warning(message)
        self._write_json("WARNING", message, **extra)

    def error(self, message: str, **extra: Any) -> None:
        self._logger.error(message)
        self._write_json("ERROR", message, **extra)

    def debug(self, message: str, **extra: Any) -> None:
        self._logger.debug(message)
        self._write_json("DEBUG", message, **extra)

    def audit_start(self, audit_id: str) -> None:
        self.info("Audit started", audit_id=audit_id, event="audit_start")

    def audit_end(self, audit_id: str, duration: float, findings: int) -> None:
        self.info(
            f"Audit completed in {duration:.2f}s with {findings} findings",
            audit_id=audit_id,
            event="audit_end",
            duration=duration,
            findings=findings,
        )
