"""Validation helpers for configurations and safety."""

from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path
from typing import List, Optional, Tuple


def run_cmd(
    cmd: List[str], timeout: int = 15
) -> Tuple[int, str, str]:
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError) as exc:
        return 1, "", str(exc)


def validate_sshd_config(config_path: Optional[Path] = None) -> Tuple[bool, str]:
    """Validate SSH daemon configuration with sshd -t."""
    if not shutil.which("sshd"):
        return False, "sshd binary not found"
    cmd = ["sshd", "-t"]
    if config_path:
        cmd.extend(["-f", str(config_path)])
    code, out, err = run_cmd(cmd)
    if code == 0:
        return True, "Configuration is valid"
    return False, err or out or "sshd -t failed"


def get_effective_sshd_config() -> Tuple[bool, dict]:
    """Return effective sshd configuration via sshd -T."""
    if not shutil.which("sshd"):
        return False, {}
    code, out, err = run_cmd(["sshd", "-T"])
    if code != 0:
        return False, {}
    result = {}
    for line in out.splitlines():
        parts = line.split(None, 1)
        if len(parts) == 2:
            result[parts[0].lower()] = parts[1]
        elif len(parts) == 1:
            result[parts[0].lower()] = ""
    return True, result


def is_safe_path(path: Path, allowed_roots: Optional[List[Path]] = None) -> bool:
    """Basic path traversal protection."""
    try:
        resolved = path.resolve()
    except OSError:
        return False
    if allowed_roots:
        for root in allowed_roots:
            try:
                resolved.relative_to(root.resolve())
                return True
            except ValueError:
                continue
        return False
    # Default: refuse obviously dangerous paths
    dangerous = ["/proc", "/sys", "/dev"]
    for d in dangerous:
        if str(resolved).startswith(d):
            return False
    return True


def parse_sysctl(key: str) -> Optional[str]:
    """Read a sysctl value safely."""
    path = Path("/proc/sys") / key.replace(".", "/")
    if not path.exists():
        return None
    try:
        return path.read_text(encoding="utf-8").strip()
    except OSError:
        return None


def set_sysctl(key: str, value: str, dry_run: bool = True) -> Tuple[bool, str]:
    """Set a sysctl value (or preview)."""
    if dry_run:
        return True, f"[dry-run] Would set {key} = {value}"
    if not shutil.which("sysctl"):
        return False, "sysctl not available"
    code, out, err = run_cmd(["sysctl", "-w", f"{key}={value}"])
    if code == 0:
        return True, out or f"Set {key}={value}"
    return False, err or out or "sysctl failed"
