"""Configuration compliance scoring."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

from .risk_engine import AuditState, Finding, Severity


# Weights for scoring (higher = more important)
SEVERITY_WEIGHT = {
    Severity.CRITICAL: 10.0,
    Severity.HIGH: 5.0,
    Severity.MEDIUM: 2.0,
    Severity.LOW: 1.0,
    Severity.INFO: 0.0,
}


@dataclass
class ScoreResult:
    score: float  # 0-100
    coverage: float  # 0-100
    evaluated: int
    total_checks: int
    critical: int = 0
    high: int = 0
    medium: int = 0
    low: int = 0
    info: int = 0
    passed: int = 0
    failed: int = 0
    warnings: int = 0
    unknown: int = 0
    na: int = 0
    formula: str = ""

    def to_dict(self) -> Dict:
        return {
            "score": round(self.score, 1),
            "coverage": round(self.coverage, 1),
            "evaluated": self.evaluated,
            "total_checks": self.total_checks,
            "critical": self.critical,
            "high": self.high,
            "medium": self.medium,
            "low": self.low,
            "info": self.info,
            "passed": self.passed,
            "failed": self.failed,
            "warnings": self.warnings,
            "unknown": self.unknown,
            "na": self.na,
            "formula": self.formula,
        }


def calculate_score(findings: List[Finding]) -> ScoreResult:
    """
    Calculate configuration compliance score.

    Rules:
    - Exclude UNKNOWN and N/A from the denominator.
    - PASS contributes full weight.
    - FAIL subtracts full weight of its severity.
    - WARNING contributes 0 (no points awarded).
    - INFO is informational only.
    - Score = (earned / possible) * 100
    """
    result = ScoreResult(score=0.0, coverage=0.0, evaluated=0, total_checks=len(findings))

    possible = 0.0
    earned = 0.0

    for f in findings:
        if f.state == AuditState.PASS:
            result.passed += 1
            w = SEVERITY_WEIGHT.get(f.severity, 1.0)
            # INFO passes don't affect score
            if f.severity != Severity.INFO:
                possible += w
                earned += w
        elif f.state == AuditState.FAIL:
            result.failed += 1
            w = SEVERITY_WEIGHT.get(f.severity, 1.0)
            possible += w
            # earned stays 0 for this check
            if f.severity == Severity.CRITICAL:
                result.critical += 1
            elif f.severity == Severity.HIGH:
                result.high += 1
            elif f.severity == Severity.MEDIUM:
                result.medium += 1
            elif f.severity == Severity.LOW:
                result.low += 1
        elif f.state == AuditState.WARNING:
            result.warnings += 1
            # WARNING does not award points and does not count as failure weight
            # but we still count severity for summary
            if f.severity == Severity.CRITICAL:
                result.critical += 1
            elif f.severity == Severity.HIGH:
                result.high += 1
            elif f.severity == Severity.MEDIUM:
                result.medium += 1
            elif f.severity == Severity.LOW:
                result.low += 1
        elif f.state == AuditState.UNKNOWN:
            result.unknown += 1
        elif f.state == AuditState.NA:
            result.na += 1
        else:
            result.unknown += 1

        if f.severity == Severity.INFO and f.state == AuditState.PASS:
            result.info += 1

    result.evaluated = result.passed + result.failed + result.warnings
    if result.total_checks > 0:
        result.coverage = (result.evaluated / result.total_checks) * 100.0
    else:
        result.coverage = 0.0

    if possible > 0:
        result.score = (earned / possible) * 100.0
    else:
        # No weighted checks → neutral 100 if nothing failed, else 0
        result.score = 100.0 if result.failed == 0 else 0.0

    result.formula = (
        "Score = (sum of weights of PASS checks) / "
        "(sum of weights of PASS + FAIL checks) * 100. "
        "UNKNOWN and N/A excluded. WARNING awards 0 points."
    )
    return result
