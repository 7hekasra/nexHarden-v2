"""Configuration management for nexHarden."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional


class Config:
    """Application configuration."""

    DEFAULTS = {
        "history_enabled": True,
        "history_retention": 30,
        "report_dir": "reports",
        "backup_dir": "backups",
        "history_dir": "history",
        "log_dir": "logs",
        "default_profile": "basic",
        "strict_html_escape": True,
    }

    def __init__(self, project_root: Optional[Path] = None) -> None:
        if project_root is None:
            # Detect from this file location
            self.project_root = Path(__file__).resolve().parent.parent
        else:
            self.project_root = Path(project_root)

        self._data: Dict[str, Any] = dict(self.DEFAULTS)
        self._load_user_config()

    def _load_user_config(self) -> None:
        cfg_path = self.project_root / "nexharden.json"
        if cfg_path.exists():
            try:
                with open(cfg_path, "r", encoding="utf-8") as fh:
                    user = json.load(fh)
                    if isinstance(user, dict):
                        self._data.update(user)
            except (OSError, json.JSONDecodeError):
                pass

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)

    def path(self, key: str) -> Path:
        """Return an absolute path for a configured directory key."""
        rel = self._data.get(key, key)
        p = Path(rel)
        if not p.is_absolute():
            p = self.project_root / p
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def report_dir(self) -> Path:
        return self.path("report_dir")

    @property
    def backup_dir(self) -> Path:
        return self.path("backup_dir")

    @property
    def history_dir(self) -> Path:
        return self.path("history_dir")

    @property
    def log_dir(self) -> Path:
        return self.path("log_dir")
