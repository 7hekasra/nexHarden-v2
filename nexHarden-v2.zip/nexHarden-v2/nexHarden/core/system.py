"""System detection and information gathering."""

from __future__ import annotations

import os
import platform
import re
import shutil
import socket
import subprocess
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class SystemInfo:
    """Collected system information."""

    hostname: str = ""
    distribution: str = "unknown"
    distribution_id: str = "unknown"
    version: str = "unknown"
    codename: str = ""
    kernel: str = ""
    architecture: str = ""
    uptime_seconds: float = 0.0
    uptime_human: str = ""
    init_system: str = "unknown"
    package_manager: str = "unknown"
    is_root: bool = False
    current_user: str = ""
    is_supported: bool = False
    support_notes: List[str] = field(default_factory=list)
    firewall_backend: str = "none"
    active_interfaces: List[str] = field(default_factory=list)
    security_utilities: Dict[str, bool] = field(default_factory=dict)
    is_desktop: Optional[bool] = None
    is_server: Optional[bool] = None
    ssh_port: Optional[int] = None
    ssh_service: str = "unknown"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class SystemDetector:
    """Detects distribution, architecture, and system characteristics."""

    SUPPORTED = {
        "debian": {"12", "13"},
        "ubuntu": {"22.04", "24.04"},
    }

    def __init__(self) -> None:
        self.info = SystemInfo()

    def detect(self) -> SystemInfo:
        self._detect_basic()
        self._detect_distribution()
        self._detect_init()
        self._detect_package_manager()
        self._detect_firewall()
        self._detect_interfaces()
        self._detect_security_utils()
        self._detect_role()
        self._detect_ssh()
        self._evaluate_support()
        return self.info

    def _run(
        self, cmd: List[str], timeout: int = 10
    ) -> Tuple[int, str, str]:
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
            )
            return result.returncode, result.stdout.strip(), result.stderr.strip()
        except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
            return 1, "", ""

    def _detect_basic(self) -> None:
        self.info.hostname = socket.gethostname()
        self.info.kernel = platform.release()
        self.info.architecture = platform.machine()
        self.info.current_user = os.environ.get("USER", os.environ.get("LOGNAME", "unknown"))
        self.info.is_root = os.geteuid() == 0

        # Uptime
        try:
            with open("/proc/uptime", "r", encoding="utf-8") as fh:
                uptime = float(fh.read().split()[0])
                self.info.uptime_seconds = uptime
                days = int(uptime // 86400)
                hours = int((uptime % 86400) // 3600)
                mins = int((uptime % 3600) // 60)
                parts = []
                if days:
                    parts.append(f"{days}d")
                if hours:
                    parts.append(f"{hours}h")
                parts.append(f"{mins}m")
                self.info.uptime_human = " ".join(parts)
        except OSError:
            self.info.uptime_human = "unknown"

    def _detect_distribution(self) -> None:
        # Prefer /etc/os-release
        os_release = Path("/etc/os-release")
        data: Dict[str, str] = {}
        if os_release.exists():
            try:
                with open(os_release, "r", encoding="utf-8") as fh:
                    for line in fh:
                        line = line.strip()
                        if "=" in line and not line.startswith("#"):
                            key, val = line.split("=", 1)
                            data[key] = val.strip().strip('"')
            except OSError:
                pass

        self.info.distribution = data.get("NAME", "unknown")
        self.info.distribution_id = data.get("ID", "unknown").lower()
        self.info.version = data.get("VERSION_ID", "unknown")
        self.info.codename = data.get("VERSION_CODENAME", "")

        # Fallback
        if self.info.distribution_id == "unknown":
            if Path("/etc/debian_version").exists():
                self.info.distribution_id = "debian"
                try:
                    self.info.version = Path("/etc/debian_version").read_text().strip()
                except OSError:
                    pass

    def _detect_init(self) -> None:
        if Path("/run/systemd/system").exists():
            self.info.init_system = "systemd"
        elif shutil.which("init") and Path("/sbin/init").is_symlink():
            target = os.readlink("/sbin/init")
            if "systemd" in target:
                self.info.init_system = "systemd"
            else:
                self.info.init_system = "sysvinit"
        else:
            self.info.init_system = "unknown"

    def _detect_package_manager(self) -> None:
        if shutil.which("apt-get") or shutil.which("apt"):
            self.info.package_manager = "apt"
        elif shutil.which("dnf"):
            self.info.package_manager = "dnf"
        elif shutil.which("yum"):
            self.info.package_manager = "yum"
        elif shutil.which("pacman"):
            self.info.package_manager = "pacman"
        else:
            self.info.package_manager = "unknown"

    def _detect_firewall(self) -> None:
        # Order of preference for detection
        if shutil.which("ufw"):
            code, out, _ = self._run(["ufw", "status"])
            if code == 0 and "active" in out.lower():
                self.info.firewall_backend = "ufw"
                return
            if code == 0:
                self.info.firewall_backend = "ufw (inactive)"
                return

        if shutil.which("firewall-cmd"):
            code, out, _ = self._run(["firewall-cmd", "--state"])
            if code == 0 and "running" in out.lower():
                self.info.firewall_backend = "firewalld"
                return

        if shutil.which("nft"):
            code, out, _ = self._run(["nft", "list", "ruleset"])
            if code == 0 and out.strip():
                self.info.firewall_backend = "nftables"
                return

        if shutil.which("iptables"):
            code, out, _ = self._run(["iptables", "-L", "-n"])
            if code == 0:
                self.info.firewall_backend = "iptables"
                return

        self.info.firewall_backend = "none"

    def _detect_interfaces(self) -> None:
        try:
            for entry in Path("/sys/class/net").iterdir():
                name = entry.name
                if name == "lo":
                    continue
                oper = entry / "operstate"
                if oper.exists():
                    state = oper.read_text().strip()
                    if state == "up":
                        self.info.active_interfaces.append(name)
        except OSError:
            pass

    def _detect_security_utils(self) -> None:
        utils = [
            "sshd", "ssh", "ufw", "nft", "iptables", "firewall-cmd",
            "auditd", "aide", "fail2ban", "apparmor_status", "getenforce",
            "sysctl", "ss", "netstat", "journalctl", "systemctl",
        ]
        for util in utils:
            self.info.security_utilities[util] = shutil.which(util) is not None

    def _detect_role(self) -> None:
        # Heuristic: presence of desktop packages or display
        desktop_hints = [
            Path("/usr/share/xsessions").exists(),
            Path("/usr/share/wayland-sessions").exists(),
            os.environ.get("DISPLAY") is not None,
            os.environ.get("WAYLAND_DISPLAY") is not None,
        ]
        if any(desktop_hints):
            self.info.is_desktop = True
            self.info.is_server = False
        else:
            # Server-ish if no desktop and has common server services
            self.info.is_desktop = False
            self.info.is_server = True

    def _detect_ssh(self) -> None:
        # Detect listening SSH port and service name
        if shutil.which("ss"):
            code, out, _ = self._run(["ss", "-tlnp"])
            if code == 0:
                for line in out.splitlines():
                    if ":22 " in line or "*:22" in line:
                        self.info.ssh_port = 22
                    m = re.search(r":(\d+)\s", line)
                    if m and "sshd" in line:
                        self.info.ssh_port = int(m.group(1))

        if self.info.init_system == "systemd" and shutil.which("systemctl"):
            for svc in ("ssh", "sshd"):
                code, out, _ = self._run(["systemctl", "is-active", svc])
                if code == 0 and out.strip() == "active":
                    self.info.ssh_service = svc
                    break

        if self.info.ssh_port is None:
            self.info.ssh_port = 22  # common default

    def _evaluate_support(self) -> None:
        distro = self.info.distribution_id
        version = self.info.version

        if distro in self.SUPPORTED:
            # Match major version for Debian, full for Ubuntu
            if distro == "debian":
                major = version.split(".")[0]
                if major in self.SUPPORTED[distro]:
                    self.info.is_supported = True
                else:
                    self.info.support_notes.append(
                        f"Debian {version} is not in the primary support matrix "
                        f"(supported: {', '.join(sorted(self.SUPPORTED[distro]))})."
                    )
            elif distro == "ubuntu":
                if version in self.SUPPORTED[distro]:
                    self.info.is_supported = True
                else:
                    # Accept newer point releases of supported series
                    for supported in self.SUPPORTED[distro]:
                        if version.startswith(supported.split(".")[0] + "."):
                            self.info.is_supported = True
                            self.info.support_notes.append(
                                f"Ubuntu {version} is treated as compatible with {supported}."
                            )
                            break
                    if not self.info.is_supported:
                        self.info.support_notes.append(
                            f"Ubuntu {version} is not in the primary support matrix."
                        )
        else:
            self.info.support_notes.append(
                f"Distribution '{distro}' is not officially supported. "
                "Results may be incomplete or inaccurate."
            )

        if self.info.architecture not in ("x86_64", "amd64", "aarch64", "arm64"):
            self.info.support_notes.append(
                f"Architecture {self.info.architecture} has limited testing."
            )

        if self.info.package_manager != "apt":
            self.info.support_notes.append(
                "Package security checks require APT and may be limited."
            )
