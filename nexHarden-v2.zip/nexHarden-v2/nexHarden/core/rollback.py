"""Safe rollback of hardening transactions."""

from __future__ import annotations

import hashlib
import os
import shutil
import stat
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .backup import BackupManager


class RollbackManager:
    """Restores files from a previous transaction with safety checks."""

    def __init__(self, backup_manager: BackupManager) -> None:
        self.bm = backup_manager

    def _hash_file(self, path: Path) -> str:
        h = hashlib.sha256()
        try:
            with open(path, "rb") as fh:
                for chunk in iter(lambda: fh.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except OSError:
            return ""

    def preview(self, tx_id: str) -> Dict[str, Any]:
        """Return what would be restored."""
        record = self.bm.load_transaction(tx_id)
        if not record:
            return {"error": f"Transaction {tx_id} not found"}

        preview: Dict[str, Any] = {
            "transaction_id": tx_id,
            "status": record.get("status"),
            "files": [],
            "safe": True,
            "warnings": [],
        }

        for orig_path, info in record.get("files", {}).items():
            item: Dict[str, Any] = {
                "path": orig_path,
                "backup_exists": False,
                "current_matches_after": False,
                "can_restore": False,
            }
            backup_path = info.get("backup_path")
            if backup_path and Path(backup_path).exists():
                item["backup_exists"] = True
            else:
                preview["warnings"].append(f"Backup missing for {orig_path}")
                preview["safe"] = False
                preview["files"].append(item)
                continue

            current = Path(orig_path)
            meta_after = info.get("meta_after", {})
            expected_hash = meta_after.get("sha256", "")

            if current.exists() and expected_hash:
                current_hash = self._hash_file(current)
                if current_hash == expected_hash:
                    item["current_matches_after"] = True
                    item["can_restore"] = True
                else:
                    item["can_restore"] = False
                    preview["warnings"].append(
                        f"File {orig_path} has been modified since the hardening "
                        "transaction. Automatic restore refused to avoid "
                        "overwriting user changes."
                    )
                    preview["safe"] = False
            elif not current.exists():
                # File was removed; restoring is usually safe
                item["can_restore"] = True
            else:
                item["can_restore"] = True  # no after-hash available

            preview["files"].append(item)

        return preview

    def rollback(
        self, tx_id: str, confirm: bool = False
    ) -> Tuple[bool, str, List[str]]:
        """
        Perform rollback.

        Returns (success, message, restored_paths).
        """
        if not confirm:
            return False, "Explicit confirmation required (pass confirm=True).", []

        preview = self.preview(tx_id)
        if "error" in preview:
            return False, preview["error"], []

        if not preview.get("safe", False):
            return (
                False,
                "Rollback refused due to safety checks: "
                + "; ".join(preview.get("warnings", [])),
                [],
            )

        record = self.bm.load_transaction(tx_id)
        if not record:
            return False, "Transaction record disappeared.", []

        restored: List[str] = []
        errors: List[str] = []

        for orig_path, info in record.get("files", {}).items():
            backup_path = info.get("backup_path")
            if not backup_path or not Path(backup_path).exists():
                errors.append(f"No backup for {orig_path}")
                continue

            target = Path(orig_path)
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(backup_path, target)
                # Best-effort restore ownership/mode from meta_before
                meta = info.get("meta_before", {})
                if "uid" in meta and "gid" in meta and os.geteuid() == 0:
                    try:
                        os.chown(target, meta["uid"], meta["gid"])
                    except OSError:
                        pass
                restored.append(orig_path)
            except OSError as exc:
                errors.append(f"Failed to restore {orig_path}: {exc}")

        if restored:
            self.bm.finalize(tx_id, status="rolled_back")

        if errors and not restored:
            return False, "Rollback failed: " + "; ".join(errors), []
        if errors:
            return (
                True,
                f"Partial rollback. Restored {len(restored)} file(s). Errors: "
                + "; ".join(errors),
                restored,
            )
        return True, f"Successfully restored {len(restored)} file(s).", restored
