"""Safe hardening executor with dry-run and transaction support."""

from __future__ import annotations

import json
import os
import shutil
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .backup import BackupManager
from .logger import StructuredLogger
from .validators import run_cmd, validate_sshd_config


class HardeningAction:
    """Describes a single proposed change."""

    def __init__(
        self,
        module: str,
        title: str,
        description: str,
        target_files: List[str],
        risk: str = "medium",
        requires_root: bool = True,
        reversible: bool = True,
        reboot_required: bool = False,
        validation_cmd: Optional[List[str]] = None,
    ) -> None:
        self.module = module
        self.title = title
        self.description = description
        self.target_files = target_files
        self.risk = risk
        self.requires_root = requires_root
        self.reversible = reversible
        self.reboot_required = reboot_required
        self.validation_cmd = validation_cmd
        self.applied = False
        self.result_message = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "module": self.module,
            "title": self.title,
            "description": self.description,
            "target_files": self.target_files,
            "risk": self.risk,
            "requires_root": self.requires_root,
            "reversible": self.reversible,
            "reboot_required": self.reboot_required,
            "applied": self.applied,
            "result_message": self.result_message,
        }


class Executor:
    """Coordinates dry-run, backup, apply, and verification."""

    def __init__(
        self,
        backup_manager: BackupManager,
        logger: StructuredLogger,
        dry_run: bool = True,
    ) -> None:
        self.bm = backup_manager
        self.logger = logger
        self.dry_run = dry_run
        self.actions: List[HardeningAction] = []
        self.transaction_id: Optional[str] = None

    def add_action(self, action: HardeningAction) -> None:
        self.actions.append(action)

    def preview(self) -> List[Dict[str, Any]]:
        return [a.to_dict() for a in self.actions]

    def apply(
        self,
        profile: str,
        confirm: bool = False,
        apply_fn=None,
    ) -> Tuple[bool, str, Optional[str]]:
        """
        Apply collected actions.

        apply_fn(action, dry_run) -> (success, message) is called for each action.
        """
        if not self.actions:
            return True, "No actions to apply.", None

        if not confirm and not self.dry_run:
            return False, "Explicit confirmation required for non-dry-run apply.", None

        if self.dry_run:
            msgs = []
            for a in self.actions:
                msgs.append(f"[DRY-RUN] {a.title}: {a.description}")
            return True, "\n".join(msgs), None

        # Real apply
        files = []
        for a in self.actions:
            for f in a.target_files:
                p = Path(f)
                if p.exists():
                    files.append(p)

        record = self.bm.create_transaction(
            profile=profile,
            description=f"Hardening profile {profile}",
            files=files,
        )
        self.transaction_id = record["transaction_id"]
        self.logger.info(
            f"Created transaction {self.transaction_id}",
            event="transaction_created",
            tx_id=self.transaction_id,
        )

        success_count = 0
        errors = []

        for action in self.actions:
            if action.requires_root and os.geteuid() != 0:
                action.result_message = "Skipped: root required"
                errors.append(f"{action.title}: root required")
                continue

            try:
                if apply_fn:
                    ok, msg = apply_fn(action, dry_run=False)
                else:
                    ok, msg = False, "No apply function provided"
                action.applied = ok
                action.result_message = msg
                if ok:
                    success_count += 1
                    self.bm.record_change(
                        self.transaction_id,
                        ",".join(action.target_files),
                        "modified",
                        msg,
                    )
                else:
                    errors.append(f"{action.title}: {msg}")
            except Exception as exc:  # noqa: BLE001
                action.result_message = str(exc)
                errors.append(f"{action.title}: {exc}")

        status = "applied" if success_count == len(self.actions) else "partial"
        self.bm.finalize(self.transaction_id, status=status)

        if errors:
            return (
                success_count > 0,
                f"Applied {success_count}/{len(self.actions)}. Errors: "
                + "; ".join(errors),
                self.transaction_id,
            )
        return True, f"Successfully applied {success_count} action(s).", self.transaction_id
